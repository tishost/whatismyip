package com.example.what_is_my_ip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

